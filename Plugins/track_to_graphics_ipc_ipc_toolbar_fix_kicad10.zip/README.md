# Selected Tracks to Graphics — KiCad 10 IPC API (active documentation layer)

Minimal Python IPC plugin for KiCad 10. No deprecated `pcbnew` / SWIG API.

## Install or upgrade (Ubuntu)

1. In **Preferences → Preferences → Plugins**, enable **Enable KiCad API** and verify a Python interpreter is configured.
2. Extract the ZIP and copy **only** `track_to_graphics_ipc/` into `~/.local/share/kicad/10.0/plugins/`. The IPC plugins directory is **not** `.../scripting/plugins/` (that path is used by legacy SWIG Action Plugins). Replace the older folder of the same name; **do not install both**. Plugin identifier remains unchanged. The folder must contain `plugin.json`, `requirements.txt` and `track_to_graphics_action.py` directly, with no extra nesting.
3. Fully close and restart PCB Editor. On first discovery KiCad creates a managed Python environment and installs the pinned `kicad-python==0.8.0` dependency. If the plugin appears but fails to load, use **Recreate Plugin Environment** in Preferences → Plugins. If nothing appears, inspect the warning/alert triangle in the lower-right status bar.
4. In **Board Setup → Board Stackup → Board Editor Layers**, enable a `User.*` layer and set its category to **Auxiliary**; optionally rename it `Impedance_map`.
5. Select this documentation layer as the **active** layer (highlighted in KiCad's Layers/Appearance panel).
6. Select the desired **straight copper track segments** in the PCB view, then run **Tools → External Plugins → Copy Selected Tracks to Graphics**.
7. Inspect results, then save the PCB if correct. Original copper is unchanged.

## Destination rules and safeguards

The plugin queries `board.get_active_layer()` at execution time, checks the actual layer **ID**, and requires that the layer is enabled. It never changes the active layer or the board layer configuration.

Allowed: KiCad's user-defined layers `User.1` … `User.45`, and `Dwgs.User`, `Cmts.User`, `Eco1.User`, `Eco2.User` (including renamed versions). Different active user layers are supported on subsequent runs.

Rejected: **all copper**, silkscreen, solder mask, solder paste, fab, courtyard, Edge.Cuts and other physical layers. Wrong/disabled layer causes a clear error **before making any board changes**.

**Important distinction:** a `User.*` layer is always **non-copper**, but KiCad allows configuring its layer subtype as **Auxiliary**, **Off-board front** or **Off-board back**. KiCad 10's published IPC layer API does not expose that subtype for a reliable live test; the plugin therefore cannot technically guarantee an *Auxiliary* subtype. Configure it explicitly to **Auxiliary** in Board Setup. This is a limitation of the validation, not a claim that every User.* layer is Auxiliary.

## Copy behavior

- Operates on **currently selected straight track segments**, not full nets.
- Copies endpoints and line widths onto the current allowed documentation layer as `BoardSegment` objects.
- Does not copy vias, arc tracks, pads, zones, net attributes or copper layer identity.
- Deduplicates exact geometry on the chosen layer, including reversed endpoints and repeated run; does not deduplicate across *different* destination layers.
- Creates new graphics in one undoable board transaction; never removes or edits copper.
- Existing graphics do not follow later PCB routing changes. Clear/recreate annotations when routing is revised.
- Export a **separately labelled documentation drawing/PDF**, not a copper Gerber. The graphic copies alone do not establish controlled impedance.

## Tests and verification

Run `python -m unittest discover -s tests -v` and `python -m compileall -q track_to_graphics_ipc`.

Stand-in tests cover active user-layer resolution, renamed layers, wrong/disabled layers, duplicate detection, persistence across destination layers, and absence of copper changes. Native KiCad 10 IPC execution and in-app discovery have **not** been performed and require a GUI smoke test. The archive layout, syntax and stand-in tests are checked, but do not prove application compatibility.

Official KiCad API references:

- https://docs.kicad.org/kicad-python/board.html (`get_active_layer()`, `get_layer_name()`, `get_enabled_layers()`)
- https://dev-docs.kicad.org/en/apis-and-binding/ipc-api/for-addon-developers/
- https://docs.kicad.org/10.0/en/pcbnew/pcbnew.html (User.* layer subtype selection)

No AFC repo or layout was modified.

## Linux directory quick fix (from older incorrectly installed IPC archive)

For a user installation, the correct IPC path is:

```text
~/.local/share/kicad/10.0/plugins/track_to_graphics_ipc/plugin.json
~/.local/share/kicad/10.0/plugins/track_to_graphics_ipc/requirements.txt
~/.local/share/kicad/10.0/plugins/track_to_graphics_ipc/track_to_graphics_action.py
```

Don't use `.../scripting/plugins/` for IPC plugins. That folder is opened by the legacy Action Plugin directory menu. For diagnosis:

```bash
find ~/.local/share/kicad/10.0/plugins/track_to_graphics_ipc -maxdepth 1 -type f -printf '%f\n'
```

KiCad 10 **Preferences → Plugins** must have **Enable KiCad API** checked. Start `kicad` from a terminal with `KICAD_ENABLE_WXTRACE=1 WXTRACE=KICAD_API kicad` if plugin startup continues to fail. Check KiCad's status-bar alerts.

## KiCad 10 toolbar/menu registration repair

This repackaging fixes the initial `show-button: false` manifest and adds the
`icons-light`/`icons-dark` icons. This is a registration/visibility improvement,
not proof that KiCad will load or execute the plugin on a particular machine.

After installing, confirm **Preferences → Preferences → Plugins → Enable KiCad
API** (this is the global Plugins entry, not **PCB Editor → Plugins**). In the
PCB Editor, use **Preferences → Preferences → PCB Editor → Plugins** and ensure
**Show Button** is checked for this action. Click **OK** to apply. Under
**PCB Editor → Toolbars**, verify the toolbar has the **IPC/Scripting plugins**
section enabled, if your customized toolbar contains such sections. Restart
PCB Editor after the change.

If the entry is listed but neither button nor menu appears, right-click the
action row and choose **Recreate Plugin Environment**. Look for an alert in the
PCB Editor's bottom-right status bar. For the precise startup cause launch KiCad
from a terminal with:

    KICAD_ENABLE_WXTRACE=1 WXTRACE=KICAD_API kicad 2>&1 | tee /tmp/kicad-ipc-plugin.log

Inspect errors mentioning the plugin identifier
`org.openpcb.track-to-graphics-ipc`, missing dependencies, Python interpreter,
or the entrypoint. If it still fails, capture the relevant log lines.

This is a manually installed IPC plugin, not a Plugin and Content Manager ZIP.
Extract only the `track_to_graphics_ipc/` folder under
`~/.local/share/kicad/10.0/plugins/`.
