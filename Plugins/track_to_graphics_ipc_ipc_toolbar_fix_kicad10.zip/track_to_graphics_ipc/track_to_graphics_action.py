"""KiCad 10 IPC plugin: copy selected straight copper tracks to graphics.

Uses kicad-python's supported IPC bindings, not the deprecated pcbnew SWIG API.
No board/project files are accessed outside the current KiCad IPC session.
"""

from __future__ import annotations

from kipy import KiCad
from kipy.board_types import BoardLayer, BoardSegment, Track

# Only documentation-only, non-copper layers are eligible.
# User.1...User.45 are often configured as Auxiliary, but can also be
# configured as Off-board front/back; the KiCad 10 IPC API does not expose
# that subtype. The user must set it to Auxiliary in Board Setup if desired.
AUXILIARY_STANDARD_LAYERS = (
    BoardLayer.BL_Dwgs_User,
    BoardLayer.BL_Cmts_User,
    BoardLayer.BL_Eco1_User,
    BoardLayer.BL_Eco2_User,
)


def allowed_documentation_layers():
    """Allow only KiCad documentation-layer IDs, never physical fabrication layers.

    KiCad names can be customized; checking display names alone is unsafe.
    """
    result = set(AUXILIARY_STANDARD_LAYERS)
    for index in range(1, 46):
        layer = getattr(BoardLayer, f"BL_User_{index}", None)
        if layer is not None:
            result.add(layer)
    return result


def resolve_destination_layer(board):
    """Read the editor's current layer, validate it, and never change it."""
    layer = board.get_active_layer()
    name = board.get_layer_name(layer)
    if layer not in allowed_documentation_layers():
        raise ValueError(
            f"Current layer '{name}' is not a user/documentation layer. "
            "Select an enabled Auxiliary User.* layer (or Dwgs.User, "
            "Cmts.User, Eco1.User, Eco2.User) before running. "
            "Copper, fab, silkscreen, paste and mask layers are not allowed."
        )
    if layer not in board.get_enabled_layers():
        raise ValueError(
            f"Current documentation layer '{name}' is disabled. "
            "Enable it in Board Setup before running."
        )
    return layer, name


def geometry_key(start, end, width):
    """Order-independent key. KiCad coordinates and widths are in nanometres."""
    a = (int(start.x), int(start.y))
    b = (int(end.x), int(end.y))
    return (min(a, b), max(a, b), int(width))


def copy_selected_segments(board) -> tuple[int, int, int]:
    """Return (created, already_present, selected_straight_tracks).

    Only the currently active enabled documentation layer is used. Geometry
    deduplication is specific to that layer, never across separate layers.
    """
    destination_layer, _ = resolve_destination_layer(board)
    selected = [item for item in board.get_selection() if isinstance(item, Track)]
    if not selected:
        return (0, 0, 0)

    present = {
        geometry_key(graphic.start, graphic.end, graphic.attributes.stroke.width)
        for graphic in board.get_shapes()
        if isinstance(graphic, BoardSegment) and graphic.layer == destination_layer
    }

    candidates = []
    skipped = 0
    for track in selected:
        key = geometry_key(track.start, track.end, track.width)
        if key in present:
            skipped += 1
            continue
        # A separate BoardSegment is created. No track is changed or removed.
        graphic = BoardSegment()
        graphic.layer = destination_layer
        graphic.start = track.start
        graphic.end = track.end
        graphic.attributes.stroke.width = track.width
        candidates.append(graphic)
        present.add(key)

    if not candidates:
        return (0, skipped, len(selected))

    commit = board.begin_commit()
    try:
        created = board.create_items(candidates)
        if len(created) != len(candidates):
            raise RuntimeError(
                f"KiCad created {len(created)} of {len(candidates)} graphics; "
                "check the board before retrying"
            )
        board.push_commit(commit, "Copy selected tracks to documentation graphics")
    except Exception:
        # Do not push the transaction when API creation fails. Depending on
        # KiCad's API version, an unpushed commit may require manual inspection.
        raise

    return (len(created), skipped, len(selected))


def main() -> None:
    board = KiCad().get_board()
    destination_layer, destination_name = resolve_destination_layer(board)
    created, skipped, total = copy_selected_segments(board)
    print(
        f"Selected Tracks to Graphics: {total} straight segments selected; "
        f"{created} graphics created on '{destination_name}' (layer {destination_layer}); "
        f"{skipped} duplicates skipped."
    )
    if total == 0:
        print("Select individual copper track segments first. Arcs and vias are not copied.")


if __name__ == "__main__":
    main()
